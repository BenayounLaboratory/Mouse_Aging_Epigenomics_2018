setwd('/Volumes/MyBook_3/BD_aging_project/ChIP-seq/All_tissues_analysis/Pathway_Enrichments/GOrilla_analysis/Summary/')
options(stringsAsFactors=F)

source('Process_gorilla_like_results_FUNCTIONS.R')

# 2017-05-22
# process GOrilla-like results files for chromatin

# DecreasingFC => upregulated processes  (positive logFC first)
# IncreasingFC => downregulated processes (negative logFC first)

# 2017-06-09
# get also publicly available data, plot on the pathways that are significant in my data


# 2017-06-17
# KEGG 2017 no diseases

################# H3K27ac_intensity ################# 
#######  Pathway enrichments #######
get_enrich_balloons("MSIgDB_Hallmark_Datasets",3,'H3K27ac_intensity')
get_enrich_balloons("KEGG_2017",3,'H3K27ac_intensity')
######################################################
#######  TF targets enrichments #######
get_enrich_balloons("TF-LOF_Expression_from_GEO_WITH_FOXO_parsed-and-aggregated",3,'H3K27ac_intensity')
######################################################

################# H3K4me3_breadth ################# 
#######  Pathway enrichments #######
get_enrich_balloons("MSIgDB_Hallmark_Datasets",3,'H3K4me3_breadth')
get_enrich_balloons("KEGG_2017",3,'H3K4me3_breadth')
######################################################
#######  TF targets enrichments #######
get_enrich_balloons("TF-LOF_Expression_from_GEO_WITH_FOXO_parsed-and-aggregated",3,'H3K4me3_breadth')
######################################################

################# H3K4me3_intensity ################# 
#######  Pathway enrichments #######
get_enrich_balloons("MSIgDB_Hallmark_Datasets",3,'H3K4me3_intensity')
get_enrich_balloons("KEGG_2017",3,'H3K4me3_intensity')
######################################################
#######  TF targets enrichments #######
get_enrich_balloons("TF-LOF_Expression_from_GEO_WITH_FOXO_parsed-and-aggregated",3,'H3K4me3_intensity')
######################################################