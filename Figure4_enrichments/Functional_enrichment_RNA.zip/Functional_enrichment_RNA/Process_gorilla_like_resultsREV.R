setwd('/Volumes/BB_Backup_3//BD_aging_project/RNAseq/All_tissues_analysis/Pathway_enrichment/GOrilla_like/Summary')
options(stringsAsFactors=F)

source('Process_gorilla_like_results_FUNCTIONS_REV.R')

# 2017-05-22
# process GOrilla-like results files

# DecreasingFC => upregulated processes  (positive logFC first)
# IncreasingFC => downregulated processes (negative logFC first)

# 2017-06-17
# run KEGG 2017 no diseases


# 2018-01-05
# some original PDFs are lost - rerun and make sure onnew computer

#######  Pathway enrichments #######
get_enrich_balloons("MSIgDB_Hallmark_Datasets",4)
get_enrich_balloons("KEGG_2017",4)
######################################################

#######  TF targets enrichments #######
get_enrich_balloons("TF-LOF_Expression_from_GEO_WITH_FOXO_parsed-and-aggregated",4)
######################################################