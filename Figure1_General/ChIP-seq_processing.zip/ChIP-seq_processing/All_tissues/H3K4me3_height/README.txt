README

# 2017-03-22
# generate global breadth MDS/PCA

# get reference gene list:
cat Annotated_peak_files/HOMER_*_Diffbind_peaks_coord.xls | cut -f 11,12,16 | sort -u > UNIQUE_genesAcc_with_H3K4me3_height.list 
# remove the header manually

Merge_H3K4me3_height_files.pl UNIQUE_genesAcc_with_H3K4me3_height.list  \
Annotated_peak_files/HOMER_Liver_Diffbind_peaks_coord.xls Height_files/Liver_Diffbind_matrix_concentration_forS2norm.txt \
Annotated_peak_files/HOMER_Heart_Diffbind_peaks_coord.xls Height_files/Heart_Diffbind_matrix_concentration_forS2norm.txt \
Annotated_peak_files/HOMER_Cerebellum_Diffbind_peaks_coord.xls Height_files/Cerebellum_Diffbind_matrix_concentration_forS2norm.txt \
Annotated_peak_files/HOMER_OB_Diffbind_peaks_coord.xls Height_files/OB_Diffbind_matrix_concentration_forS2norm_NEW.txt \
Annotated_peak_files/HOMER_NPC_combined_Diffbind_peaks_coord.xls Height_files/NPC_combined_Diffbind_matrix_concentration_forS2norm.txt > 2017-03-22_Merged_H3K4me3_heights_per_gene_for_global_analysis.txt
