README

# get reference gene list from all individual H3K4me3 breadth calls in tissue/cells
cat Breadth_Files/Merged_ALL_AGES_MERGED* | cut -f 5,6,7 | sort -u > UNIQUE_genesAcc_with_H3K4me3.list 

# remove the header manually, then run perl program to get one matrix 
Merge_H3K4me3_breadth_files.pl UNIQUE_genesAcc_with_H3K4me3.list  \
Breadth_Files/Merged_ALL_AGES_MERGED_Heart_H3K4me3.PARSED_INTERSECTIONS.xls \
Breadth_Files/Merged_ALL_AGES_MERGED_Liver_H3K4me3.PARSED_INTERSECTIONS.xls \
Breadth_Files/Merged_ALL_AGES_MERGED_Cerebellum_H3K4me3.PARSED_INTERSECTIONS.xls \
Breadth_Files/Merged_ALL_AGES_MERGED_OB_H3K4me3.PARSED_INTERSECTIONS.xls \
Breadth_Files/Merged_ALL_AGES_MERGED_CombinedNPC_H3K4me3.PARSED_INTERSECTIONS.xls \
    > 2017-03-20_Merged_breadth_all_ages_all_tissues.txt


### 2017-11-29
# also try to plot an MDS on only the top 5% domains