README

# 2017-11-29
# generate global breadth MDS/PCA for SE


# get reference gene list:

cat Annotated_Peak_files/HOMER_*_Diffbind*.xls | cut -f 11,12,16 | sort -u > UNIQUE_genesAcc_with_SE.list 
# remove the header manually

Merge_SE_files.pl UNIQUE_genesAcc_with_SE.list   \
Annotated_Peak_files/HOMER_Cerebellum_Diffbind_H3K27ac_in_SE.xls SE_files/Cerebellum_Diffbind_matrix_H3K27ac_concentration_in_SuperEnhancers.txt \
Annotated_Peak_files/HOMER_Heart_Diffbind_H3K27ac_in_SE.xls SE_files/Heart_Diffbind_matrix_H3K27ac_concentration_in_SuperEnhancers.txt \
Annotated_Peak_files/HOMER_Liver_Diffbind_H3K27ac_in_SE.xls SE_files/Liver_Diffbind_matrix_H3K27ac_concentration_in_SuperEnhancers.txt \
Annotated_Peak_files/HOMER_NPC_cultures_Diffbind_H3K27ac_pooledLane_in_SE.xls SE_files/NPCs_Diffbind_matrix_H3K27ac_concentration_in_SuperEnhancers_PooledLanes.txt \
Annotated_Peak_files/HOMER_Olfactory_Bulb_Diffbind_H3K27ac_pooledLane_in_SE.xls SE_files/OB_Diffbind_matrix_H3K27ac_concentration_in_SuperEnhancers_PooledLanes.txt > 2017-11-25_Merged_SE_heights_per_gene_for_global_analysis.txt


## had to manually rename Cereb columns (were mistakenly labeled OB)

