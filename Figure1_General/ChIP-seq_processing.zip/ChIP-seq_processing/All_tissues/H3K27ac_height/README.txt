README

# 2017-03-22
# generate global breadth MDS/PCA

# get reference gene list:

cat HOMER_*_Diffbind*.xls | cut -f 11,12,16 | sort -u > UNIQUE_genesAcc_with_H3K27ac_height.list 
# remove the header manually

../../H3K4me3_Height_aging_linear_modeling/GLOBAL_ANALYSIS/Merge_H3K4me3_height_files.pl UNIQUE_genesAcc_with_H3K27ac_height.list  \
HOMER_Cerebellum_Diffbind_H3K27ac_peaks_coord.xls Cerebellum_Diffbind_matrix_H3K27ac_concentration_forS2norm.txt \
HOMER_Heart_Diffbind_H3K27ac_peaks_coord.xls Heart_Diffbind_matrix_H3K27ac_concentration_forS2norm.txt \
HOMER_Liver_Diffbind_H3K27ac_peaks_coord.xls Liver_Diffbind_matrix_H3K27ac_concentration_forS2norm.txt \
HOMER_NPCs_Diffbind_H3K27ac_PooledLanes_peaks_coord.xls NPCs_Diffbind_matrix_H3K27ac_PooledLanes_concentration_forS2norm.txt \
HOMER_OB_Diffbind_H3K27ac_PooledLanes_peaks_coord.xls OB_Diffbind_matrix_H3K27ac_concentration_forS2norm_PooledLanes.txt > 2017-03-22_Merged_H3K27ac_heights_per_gene_for_global_analysis.txt


