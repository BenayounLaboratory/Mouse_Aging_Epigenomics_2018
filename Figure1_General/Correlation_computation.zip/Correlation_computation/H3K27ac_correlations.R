setwd('/Volumes/BB_Backup_3/BD_aging_project/2018-09_revision_analyses/Bio_replicates_clustering_Diffbind/Correlations/')
library("RColorBrewer")
library("pheatmap")

# 2018-09-11
# do correlation analysis for revsision

load("/Volumes/BB_Backup_3/BD_aging_project/ChIP-seq/All_tissues_analysis/H3K27ac_Height_aging_linear_modeling/Output_matrices_for_correlations/H3K27ac_height_result_NPCs_2018-09-11.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/ChIP-seq/All_tissues_analysis/H3K27ac_Height_aging_linear_modeling/Output_matrices_for_correlations/H3K27ac_height_result_OB_2018-09-11.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/ChIP-seq/All_tissues_analysis/H3K27ac_Height_aging_linear_modeling/Output_matrices_for_correlations/H3K27ac_height_result_Cerebellum_2018-09-11.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/ChIP-seq/All_tissues_analysis/H3K27ac_Height_aging_linear_modeling/Output_matrices_for_correlations/H3K27ac_height_result_Heart_2018-09-11.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/ChIP-seq/All_tissues_analysis/H3K27ac_Height_aging_linear_modeling/Output_matrices_for_correlations/H3K27ac_height_result_Liver_2018-09-11.RData")


my.cereb.cor.mat <- cor(my.Cerebellum.height.process[[2]])
my.heart.cor.mat <- cor(my.Heart.height.process[[2]])
my.liver.cor.mat <- cor(my.liver.height.process[[2]])
my.npc.cor.mat <- cor(my.NPCs.height.process[[2]])
my.ob.cor.mat <- cor(my.OB.height.process[[2]])


write.table(my.cereb.cor.mat,file = paste(Sys.Date(),"Cerebellum_H3K27ac_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.heart.cor.mat,file = paste(Sys.Date(),"Heart_H3K27ac_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.liver.cor.mat,file = paste(Sys.Date(),"Liver_H3K27ac_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.npc.cor.mat,file = paste(Sys.Date(),"NPCs_H3K27ac_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.ob.cor.mat,file = paste(Sys.Date(),"OB_H3K27ac_correlation_matrix.txt", sep = "_"), quote = F)


