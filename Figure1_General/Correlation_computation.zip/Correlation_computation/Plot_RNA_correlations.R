setwd('/Volumes/BB_Backup_3/BD_aging_project/2018-09_revision_analyses/Bio_replicates_clustering_Diffbind/RNA_correlation')
library("RColorBrewer")
library("pheatmap")

# 2018-09-11
# do correlation analysis for revsision

load("/Volumes/BB_Backup_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_NPCs_2015-11-19.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_OB_2015-11-19.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_cereb_2015-11-19.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_Heart_2015-11-19.RData")
load("/Volumes/BB_Backup_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_Liver_2015-11-19.RData")


my.cereb.cor.mat <- cor(my.cereb.RNAseq.process[[2]])
my.heart.cor.mat <- cor(my.heart.RNAseq.process[[2]])
my.liver.cor.mat <- cor(my.liver.RNAseq.process[[2]])
my.npc.cor.mat <- cor(my.npc.RNAseq.process[[2]])
my.ob.cor.mat <- cor(my.ob.RNAseq.process[[2]])


write.table(my.cereb.cor.mat,file = paste(Sys.Date(),"Cerebellum_RNA_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.heart.cor.mat,file = paste(Sys.Date(),"Heart_RNA_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.liver.cor.mat,file = paste(Sys.Date(),"Liver_RNA_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.npc.cor.mat,file = paste(Sys.Date(),"NPCs_RNA_correlation_matrix.txt", sep = "_"), quote = F)
write.table(my.ob.cor.mat,file = paste(Sys.Date(),"OB_RNA_correlation_matrix.txt", sep = "_"), quote = F)

