README

code to compute sample correlations for sample QC:

1. transcriptome:
	Plot_RNA_correlations.R
	
2. H3K4me3 ChIP-seq:
	H3K4me3_correlations.R
	
3. H3K27ac ChIP-seq:
	H3K27ac_correlations.R
