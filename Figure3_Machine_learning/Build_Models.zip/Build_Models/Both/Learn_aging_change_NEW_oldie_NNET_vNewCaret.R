setwd('/home/benayoun/Projects/ML')
source('NNET_helper_functions_v1.R')

load("2016-11-21_Complete_feature_matrices_FOLD_CHANGE_NA_RM.RData")
load("2017-03-20_Complete_feature_matrices_CEREB_FOLD_CHANGE_NA_RM.RData")

#####################################
## 2017-02-22
# run pca NNET
# Always remove GeneName, RNA, age_FC and FDR for run
#	my.cols.exclude <- c(1,2,3)

#####################################
## 2018-09-17
# for revision, need to rerun with same package versions as STATIC/DYNAMIC

# Keep only static features for revision
my.col.include <- c("age_change","H3K4me3_age_slope","H3K27ac_age_slope","SE_aging_slope","breadth_qt_slope","Increased_Nucs","Decreased_Nucs","Max_occupancy_log2FC_age",
					"TR", "FPKM_3m", "H3K4me3_averageIntensity_3m", "H3K27ac_averageIntensity_3m", "SE_3m","SE_score_3m","SE_TSS_Dist","maxbreadth_y","BD_qt_y",
					"BD_stat_y","H3K4me1_prom","CTCF_prom","Pol2_prom","Pol2_peaks","Pol2_abs_TSS_dist","Pol2_MACS2_max_score","CpG_promoter_percentage","CG_promoter_percentage","CTCF_peaks",
					"CTCF_abs_TSS_dist","CTCF_MACS2_max_score","Constitutive.Exon","CpG_islands" , "H3K27me3_prom","DNAseI_prom","Bivalent_status")


###########################################
############        Heart      ############ 
###########################################

# get data partition
my.heart.training.idx <- get_training_idx(my.heart.features.v2) 

# run neural nets
my.heart.nnet.samp.fit <- get_nnet_fit_with_sampling(my.heart.features.v2[,my.col.include], my.heart.training.idx)
save(my.heart.nnet.samp.fit,my.heart.training.idx,
     file = paste(Sys.Date(),"Heart_NNET_model_withSampling_aging_changes_FDR0.1.RData",sep="_"))

my.heart.nnet.noCST.fit <- get_nnet_fit_noCST(my.heart.features.v2[,my.col.include], my.heart.training.idx)
save(my.heart.nnet.noCST.fit,my.heart.training.idx,
     file = paste(Sys.Date(),"Heart_NNET_model_noCONSTANT_aging_changes_FDR0.1.RData",sep="_"))

###########################################
############        Liver      ############ 
###########################################

# get data partition
my.liver.training.idx <- get_training_idx(my.liver.features.v2) 

# run neural nets
my.liver.nnet.samp.fit <- get_nnet_fit_with_sampling(my.liver.features.v2[,my.col.include], my.liver.training.idx)
save(my.liver.nnet.samp.fit,my.liver.training.idx,
     file = paste(Sys.Date(),"Liver_NNET_model_withSampling_aging_changes_FDR0.1.RData",sep="_"))

my.liver.nnet.noCST.fit <- get_nnet_fit_noCST(my.liver.features.v2[,my.col.include], my.liver.training.idx)
save(my.liver.nnet.noCST.fit,my.liver.training.idx,
     file = paste(Sys.Date(),"Liver_NNET_model_noCONSTANT_aging_changes_FDR0.1.RData",sep="_"))

###########################################
############     Cerebellum    ############ 
###########################################

# get data partition
my.cereb.training.idx <- get_training_idx(my.cereb.features.v2) 

# run neural nets
my.cereb.nnet.samp.fit <- get_nnet_fit_with_sampling(my.cereb.features.v2[,my.col.include], my.cereb.training.idx)
save(my.cereb.nnet.samp.fit,my.cereb.training.idx,
     file = paste(Sys.Date(),"cereb_NNET_model_withSampling_aging_changes_FDR0.1.RData",sep="_"))

my.cereb.nnet.noCST.fit <- get_nnet_fit_noCST(my.cereb.features.v2[,my.col.include], my.cereb.training.idx)
save(my.cereb.nnet.noCST.fit,my.cereb.training.idx,
     file = paste(Sys.Date(),"cereb_NNET_model_noCONSTANT_aging_changes_FDR0.1.RData",sep="_"))

###########################################
############         OB        ############ 
###########################################

# get data partition
my.OB.training.idx <- get_training_idx(my.ob.features) 

# run neural nets
my.OB.nnet.samp.fit <- get_nnet_fit_with_sampling(my.ob.features.v2[,my.col.include], my.OB.training.idx)
save(my.OB.nnet.samp.fit,my.OB.training.idx,
     file = paste(Sys.Date(),"OB_withBrainExtra_NNET_model_withSampling_aging_changes_FDR0.1.RData",sep="_"))

my.OB.nnet.noCST.fit <- get_nnet_fit_noCST(my.ob.features.v2[,my.col.include], my.OB.training.idx)
save(my.OB.nnet.noCST.fit,my.OB.training.idx,
     file = paste(Sys.Date(),"OB_withBrainExtra_NNET_model_noCONSTANT_aging_changes_FDR0.1.RData",sep="_"))
