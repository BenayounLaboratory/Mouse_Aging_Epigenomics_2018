options(stringsAsFactors = FALSE)
library('pROC')
library('caret')
library(doMC)
registerDoMC(cores = 6)



######## run pca Neural Net
get_nnet_fit_with_sampling <- function(my.features.all, my.training.idx, my.samples = 100, my.seed = 1234) {
  
  set.seed(my.seed)
  my.training <- my.features.all[my.training.idx,]
  
  my.training$age_change <- factor(my.training$age_change)
  
  # sample from constant in the same number as changing examples
  my.constant.idx <- which(my.training$age_change %in% 'CONSTANT') # indeces of constant examples
  my.changing.idx <- which(my.training$age_change != 'CONSTANT') # indeces of constant examples
 
  # use 10-fold cross-validation to build the model
  my.ctrl.opt <- trainControl(method = "cv", 
                              number = 10,
                              allowParallel=TRUE,
                              verbose=F,
                              summaryFunction=getMultiClassConfusionMatrixBalancedAccuracy,
                              classProbs = TRUE)
  
  # randomForest info for mtry parameter
  # Number of variables randomly sampled as candidates at each split. 
  
  # prepare result structure
  my.nnet.sampled.fits <- vector(mode='list',length=my.samples)
  
  for ( i in 1:my.samples) {
    
    my.constant.samples <- sample(my.constant.idx, length(my.changing.idx), replace = FALSE)
    
    my.sampled.training <- my.training[c(my.constant.samples,my.changing.idx),]

    # train model with caret train function
    my.nnet.fit <- train( age_change ~ .,
                        data = my.sampled.training, # all but gene name
                        method="pcaNNet",
                        trControl = my.ctrl.opt,
                        tuneLength = 10,
                        metric="balancedAcc")
    
    my.nnet.sampled.fits[[i]] <- my.nnet.fit
  }
  
  return (my.nnet.sampled.fits)
  
}

####################
# 2016-08-03
# run without CONSTANT class

get_nnet_fit_noCST <- function(my.features.all, my.training.idx, my.seed = 1234) {
  
  set.seed(my.seed)
  my.training <- my.features.all[my.training.idx,]
  
  # remove the constant class
  my.training2 <- data.frame(my.training[my.training$age_change != 'CONSTANT',])
  my.training2$age_change <- factor(my.training2$age_change)
  
  # use 10-fold cross-validation to build the model
  my.ctrl.opt <- trainControl(method = "cv",
                              number = 10,
                              allowParallel=TRUE,
                              verbose=F,
                              summaryFunction=twoClassSummary,
                              classProbs = TRUE)
  
  # train model with caret train function
  my.nnet.fit <- train( age_change ~ .,
                      data = my.training2, # all but GeneName, age_FC, FDR
                      method="pcaNNet",
                      trControl = my.ctrl.opt,
                      tuneLength = 10,
                      metric="ROC")
  
  return ( my.nnet.fit )
  
}

##### remove NA in input matrix

rm_nas <- function(my.features){
  
  my.na <- rep(F,dim(my.features)[1])
  
  for (i in 1:dim(my.features)[1]) {
    
    if(sum(is.na(my.features[i,]) > 0)) {
      my.na[i] <- T
    }
  }
  #sum(my.na)
  return(my.features[!my.na,])
}

######## get data partition
get_training_idx <- function(my.features.all) {
    
  set.seed(1234)
  
  my.training.idx <- createDataPartition(my.features.all$age_change, p=0.67, list=FALSE) # 2/3 for training
  
  return(my.training.idx)
}

### Aaron functions
getTwoClassBalancedAccuracy <- function (data, lev = NULL, model = NULL) {
  require(pROC)
  if (!all(levels(data[, "pred"]) == levels(data[, "obs"]))){
    stop("levels of observed and predicted data do not match")
  }
  rocObject <- try(pROC:::roc(data$obs, data[, lev[1]]), silent = TRUE)
  if (class(rocObject)[1] == "try-error") {
    return(NA)
  }else{
    out <- ( sensitivity(data[, "pred"], data[, "obs"], lev[1]) + specificity(data[, "pred"], data[, "obs"], lev[2]) ) /2
    names(out) <- "balancedAcc"
    return(out)
  }
}

getMultiClassConfusionMatrixBalancedAccuracy <- function (data, lev = NULL, model = NULL) {
  
  if (!all(levels(data[, "pred"]) == levels(data[, "obs"]))){
    stop("levels of observed and predicted data do not match")
  }
  
  testConfMat <- try(confusionMatrix(data$pred, data$obs), silent = TRUE)
  if (class(testConfMat)[1] == "try-error") {
    return(NA)
  }else{
    # this gets the last trhee entries which are the 3 balanced accuracies
    
    out <- mean(testConfMat$byClass[,"Balanced Accuracy"])
    names(out) <- "balancedAcc"
    return(out)
  }
}
