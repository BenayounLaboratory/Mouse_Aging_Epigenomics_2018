setwd('/home/benayoun/Projects/ML')
source('SVM_helper_functions_v2.R')

load("2016-11-21_Complete_feature_matrices_FOLD_CHANGE_NA_RM.RData")
load("2017-03-20_Complete_feature_matrices_CEREB_FOLD_CHANGE_NA_RM.RData")


#####################################
## 2018-09-14
# for revision, learn with only dynamic

# Keep only dynamic features for revision (compare to both and only static)
my.col.include <- c("age_change","H3K4me3_age_slope","H3K27ac_age_slope","SE_aging_slope","breadth_qt_slope","Increased_Nucs","Decreased_Nucs","Max_occupancy_log2FC_age")


###########################################
############        Heart      ############ 
###########################################

# get data partition
my.heart.training.idx <- get_training_idx(my.heart.features.v2) 

# run random forest
my.heart.svm.samp.fit <- get_svm_fit_with_sampling(my.heart.features.v2[,my.col.include], my.heart.training.idx)
save(my.heart.svm.samp.fit,my.heart.training.idx,
     file = paste(Sys.Date(),"Heart_SVM_model_withSampling_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

my.heart.svm.noCST.fit <- get_svm_fit_noCST(my.heart.features.v2[,my.col.include], my.heart.training.idx)
save(my.heart.svm.noCST.fit,my.heart.training.idx,
     file = paste(Sys.Date(),"Heart_SVM_model_noCONSTANT_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

###########################################
############        Liver      ############ 
###########################################

# get data partition
my.liver.training.idx <- get_training_idx(my.liver.features.v2) 

# run random forest
my.liver.svm.samp.fit <- get_svm_fit_with_sampling(my.liver.features.v2[,my.col.include], my.liver.training.idx)
save(my.liver.svm.samp.fit,my.liver.training.idx,
     file = paste(Sys.Date(),"Liver_SVM_model_withSampling_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

my.liver.svm.noCST.fit <- get_svm_fit_noCST(my.liver.features.v2[,my.col.include], my.liver.training.idx)
save(my.liver.svm.noCST.fit,my.liver.training.idx,
     file = paste(Sys.Date(),"Liver_SVM_model_noCONSTANT_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

###########################################
############     Cerebellum    ############ 
###########################################

# get data partition
my.cereb.training.idx <- get_training_idx(my.cereb.features.v2) 

# run random forest
my.cereb.svm.samp.fit <- get_svm_fit_with_sampling(my.cereb.features.v2[,my.col.include], my.cereb.training.idx)
save(my.cereb.svm.samp.fit,my.cereb.training.idx,
     file = paste(Sys.Date(),"cereb_SVM_model_withSampling_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

my.cereb.svm.noCST.fit <- get_svm_fit_noCST(my.cereb.features.v2[,my.col.include], my.cereb.training.idx)
save(my.cereb.svm.noCST.fit,my.cereb.training.idx,
     file = paste(Sys.Date(),"cereb_SVM_model_noCONSTANT_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

###########################################
############         OB        ############ 
###########################################

# get data partition
my.OB.training.idx <- get_training_idx(my.ob.features) 

#run with extra features
my.OB.svm.samp.fit <- get_svm_fit_with_sampling(my.ob.features.v2[,my.col.include], my.OB.training.idx)
save(my.OB.svm.samp.fit,my.OB.training.idx,
     file = paste(Sys.Date(),"OB_withBrainExtra_SVM_model_withSampling_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))

my.OB.svm.noCST.fit <- get_svm_fit_noCST(my.ob.features.v2[,my.col.include], my.OB.training.idx)
save(my.OB.svm.noCST.fit,my.OB.training.idx,
     file = paste(Sys.Date(),"OB_withBrainExtra_SVM_model_noCONSTANT_aging_changes_noRNA_FDR0.1_DYNAMIC_ONLY.RData",sep="_"))
