setwd('/Volumes/MyBook_3/BD_aging_project/Machine_learning_aging/Predict_Fold_change/')

library("DESeq2")

# 2016-08-02
# examine number of significant genes at different threshold (recommended by Anshul)

##################################################################################### 
### READ ALL MATRICES

#load("/Volumes/MyBook_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_NPCs_2015-11-18.RData")
load("/Volumes/MyBook_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_Liver_2015-11-18.RData")
load("/Volumes/MyBook_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_cereb_2015-11-18.RData")
load("/Volumes/MyBook_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_Heart_2015-11-18.RData")
load("/Volumes/MyBook_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_OB_2015-11-18.RData")
load("/Volumes/MyBook_3/BD_aging_project/RNAseq/All_tissues_analysis/DEseq2_runs/Separate/RNA_seq_result_NPCs_batch_corr_2016-08-02.RData")


# make function for counting sig genes at different FDRs
get_sig_num <- function(my.deseq, my.fdr=c("0.01","0.05","0.1","0.15","0.2") ) {
  
  my.res <- rep(0,length(my.fdr))
  names(my.res) <- my.fdr
  
  for( i in 1:length(my.fdr)) {
    my.res[i] <- sum(my.deseq$padj < my.fdr[i])
  }

  return(my.res)
}
###


my.cereb <- get_sig_num(my.cereb.RNAseq.process[[1]])
my.heart <- get_sig_num(my.heart.RNAseq.process[[1]])
my.liver <- get_sig_num(my.liver.RNAseq.process[[1]])
my.npc <- get_sig_num(my.npc.RNAseq.process[[1]])
my.ob <- get_sig_num(my.ob.RNAseq.process[[1]])

rbind(my.cereb,my.heart,my.liver,my.npc,my.ob)

#           0.01 0.05 0.1 0.15  0.2
# my.cereb  249  540 772  949 1156
# my.heart   83  181 283  356  423
# my.liver  156  332 491  647  791
# my.npc      0    0   0    0    0
# my.ob      76  155 229  270  328
# 
