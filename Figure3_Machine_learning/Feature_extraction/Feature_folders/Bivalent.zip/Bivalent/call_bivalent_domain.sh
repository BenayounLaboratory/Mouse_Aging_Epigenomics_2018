intersectBed -u -a RenLab-H3K27me3-cerebellum_8weeks_broad_peaks.bed -b ALL_AGES_MERGED_Cerebellum_H3K4me3_broad_peaks.bed > Bivalent_domains_Cerebellum.bed
intersectBed -u -a RenLab-H3K27me3-Liver_8weeks_broad_peaks.bed -b ALL_AGES_MERGED_Liver_H3K4me3_broad_peaks.bed > Bivalent_domains_Liver.bed
intersectBed -u -a RenLab-H3K27me3-Heart_8weeks_broad_peaks.bed -b ALL_AGES_MERGED_Heart_H3K4me3_broad_peaks.bed > Bivalent_domains_Heart.bed
#intersectBed -u -a RenLab-H3K27me3-WholeBrain_E14.5_broad_peaks.bed -b ALL_AGES_MERGED_OB_H3K4me3_broad_peaks.bed > Bivalent_domains_OB_vs_WholeBrain.bed


annotatePeaks.pl Bivalent_domains_Cerebellum.bed mm9 > HOMER_Bivalent_domains_Cerebellum.xls
annotatePeaks.pl Bivalent_domains_Liver.bed mm9 > HOMER_Bivalent_domains_Liver.xls
annotatePeaks.pl Bivalent_domains_Heart.bed mm9 > HOMER_Bivalent_domains_Heart.xls
#annotatePeaks.pl Bivalent_domains_OB_vs_WholeBrain.bed mm9 > HOMER_Bivalent_domains_OB_vs_WholeBrain.xls
