#sort -u 2016-1-21_mm9_promoter_regions.bed > 2016-1-21_mm9_promoter_regions.UNIQUE.bed
# manually remove all chrM entries (no chromatin there!!!)



LICR_BAM='/Volumes/MyBook_3/BD_aging_project/Public_datasets/LICR_Datasets/BAM_clean'

get_traveling_ratio_v3.pl Cerebellum $LICR_BAM/RenLab-Pol2-cerebellum_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed $LICR_BAM/RenLab-Input-cerebellum_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed
get_traveling_ratio_v3.pl Heart $LICR_BAM/RenLab-Pol2-heart_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed $LICR_BAM/RenLab-Input-heart_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed
get_traveling_ratio_v3.pl Liver $LICR_BAM/RenLab-Pol2-liver_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed $LICR_BAM/RenLab-Input-liver_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed
get_traveling_ratio_v3.pl OB $LICR_BAM/RenLab-Pol2-olfactory-bulb_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed  $LICR_BAM/RenLab-Input-olfactory-bulb_8weeks_trimmed.FIXSEQ_CLEANED_READS.bed
get_traveling_ratio_v3.pl NPCs /Volumes/MyBook_3/Mechanism_NPC_Datasets/ChIP-seq_mechanisms/BAM_clean/NPC_Pol2_ChIP_AGTCAA_pf_trimmed.FIXSEQ_CLEANED_READS.bed /Volumes/MyBook_3/BD_aging_project/ChIP-seq/NPC_cultures/H3K27ac_height_NPCs/3m_Pooled_NPCs_H3.FIXSEQ_CLEANED_READS.bed

