#! /usr/bin/perl

use warnings;
use strict;
use IO::CaptureOutput qw(capture_exec);

unless (scalar @ARGV >= 1) {
	die "\nIncorrect command line arguments.\nUsage : get_prom_signal.pl <cell type> <bed ChIP>  ... <bed ChIP>\n".
	"\n";

}


# We first defined the promoter region from -300 to +300 relative to the TSS.
# We next calculated the average density/nt from normalized ChIP-seq density files.

# get input files
my $cell_type = shift @ARGV;
my $proms = "2016-1-21_mm9_promoter_regions.UNIQUE.bed";

# prepapre output lines
my @results = ();
my $start = 0;

while(scalar @ARGV > 0) {
	my $bedChIP = shift @ARGV;
	
	### 1. get sequencing depths to normalize further calculations
	my $cmd = "wc -l $bedChIP".' | perl -lane \'$_ =~ m/(\d+)\s/ ;print $1;\'';
	my $mapped_million = capture_exec($cmd);
	chomp $mapped_million;
	$mapped_million =~ s/\s//g;
		
	#my $reldepth = $mapped_million / $mapped_million2;
	
	### 2. get prom coverage
	# call coverageBed and capture output
	my $coverage_prom_IP = system("coverageBed -counts -a $bedChIP -b $proms > temp1.bed");
	open (IN,"temp1.bed") or die "temp1.bed was not found\n";
	my @coverage_prom_IP = <IN>;
	close IN;
		
	#unlink ("temp1.bed","temp2.bed");
	
	my $gene_num = scalar @coverage_prom_IP;
	
	### 3. create output lines
	
	for (my $i = 0; $i < $gene_num ; ++$i) {
		
		my @data1 = get_line_data($coverage_prom_IP[$i]);
					
		my $promlength = 600; # 300-(-300) = 600bp
		
		my $prom_av_density = (1/$promlength)*($data1[4]/($mapped_million)); # divide by mapped million reads
		
		if ($start == 0) {
			my $result_line = "$data1[0]\t$data1[1]\t$data1[2]\t$data1[3]\t$prom_av_density";
			push(@results,$result_line);
			
		} else {
			$results[$i] .= "\t$prom_av_density";
		}
				
	}
		
	++$start;
	
} 


# print output
my $out1 = $cell_type."_normalized_promoter_densities_NO_HEADER.txt";

open (OUT,'>',$out1) or die "Could not open $out1: $!\n";

#my $header = "Chrom\tStart\tEnd\tGeneName\tCount1\tCount2\tCount3\tCount4\tProm_density\tGeneBody_density\tTraveling_ratio\n";
#print OUT $header;

print OUT join("\n",@results);

close OUT;


exit;


###########################################################
# SUBROUTINES
###########################################################

###########################################################
# a subroutine that separates fields from a data line and
# returns them in an array

sub get_line_data {

    my $line = $_[0];
    
    chomp $line;
    
    my @linedata = split(/\t/, $line);
       
    return @linedata;
}
