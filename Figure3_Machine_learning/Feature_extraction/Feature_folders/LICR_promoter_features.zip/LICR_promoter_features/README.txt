# 2016-01-20
# extract LICR promoter signal

# Use the promoter file generated for Pol2 TR

extract CTCF, Pol2, H3K4me1 /// and DNAse, H3K27me3 in young samples


# see order of samples in batch file: batch_extract_prom.sh

# 2016-11-15

add DNase and H3K27me3 on Whole Brain to substitute for missing OB data
