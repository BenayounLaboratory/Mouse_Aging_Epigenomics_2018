# setwd('/Volumes/MyBook_3/BD_aging_project/Public_datasets/RNA_profile_other_species/GTex/')
setwd('/Users/benayoun/Dropbox/Manuscripts_and_Publications/2018_aging_epigenomics_data_description/Aging_omics_paper/Github_folder/Figure5_Conservation/Comparisons/GTex/')
options(stringsAsFactors=F)
library(bitops)

source('cross_species_comparison_FUN.R')

# 2017-05-22
# try to compare Human GTEX againg and my data
load("/Users/benayoun/Dropbox/Manuscripts_and_Publications/2018_aging_epigenomics_data_description/Aging_omics_paper/Github_folder/Figure3_Machine_learning/Feature_extraction/Feature_folders/RNAseq_DEseq2_results/RNA_seq_result_cereb_2015-11-19.RData")
load("/Users/benayoun/Dropbox/Manuscripts_and_Publications/2018_aging_epigenomics_data_description/Aging_omics_paper/Github_folder/Figure3_Machine_learning/Feature_extraction/Feature_folders/RNAseq_DEseq2_results/RNA_seq_result_Heart_2015-11-19.RData")
load("/Users/benayoun/Dropbox/Manuscripts_and_Publications/2018_aging_epigenomics_data_description/Aging_omics_paper/Github_folder/Figure3_Machine_learning/Feature_extraction/Feature_folders/RNAseq_DEseq2_results/RNA_seq_result_Liver_2015-11-19.RData")

# read orthology on Gencode v19
my.orthology <- read.table("2016-12-16_Correspondence_GeneName_Human_Mouse_Orthologs.txt",header=T,sep="\t")
my.orth.table <- unique(data.frame(cbind(my.orthology$Human_Symbol,my.orthology$Mouse_Symbol)))
colnames(my.orth.table) <- c("Human_Symbol","Mouse_Symbol")


# # # get comparison boxplots
# load("Male_only_data_new/2017-03-09 Heart_GTEx_data_DEseq2_aging_genename_ONLYmale_no_batch.RData")
# load("Male_only_data_new/2017-03-09 Cerebellum_GTEx_data_DEseq2_aging_genename_ONLYmale_no_batch.RData")
# load("Male_only_data_new/2017-03-08 Liver_GTEx_data_DEseq2_aging_genename_ONLYmale_no_batch.RData")
# perform_tissue_comp("Liver", my.liver.gtex.process, my.liver.RNAseq.process[[1]], my.orth.table)
# perform_tissue_comp("Heart", my.heart.gtex.process, my.heart.RNAseq.process[[1]], my.orth.table)
# perform_tissue_comp("Brain", my.cereb.gtex.process, my.cereb.RNAseq.process[[1]], my.orth.table)


load("Male_Female/2018-11-02 Cerebellum_GTEx_data_DEseq2_aging_genename_maleFemale.RData")
load("Male_Female/2018-11-02 Liver_GTEx_data_DEseq2_aging_genename_maleFemale.RData")
load("Male_Female/2018-11-03 Heart_GTEx_data_DEseq2_aging_genename_maleFemale.RData")
perform_tissue_comp("Liver_bothSex", my.liver.gtex.process, my.liver.RNAseq.process[[1]], my.orth.table)
perform_tissue_comp("Heart_bothSex", my.heart.gtex.process, my.heart.RNAseq.process[[1]], my.orth.table)
perform_tissue_comp("Brain_bothSex", my.cereb.gtex.process, my.cereb.RNAseq.process[[1]], my.orth.table)



